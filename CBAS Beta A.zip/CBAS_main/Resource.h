#ifndef RESOURCE_H
#define RESOURCE_H

#define CBAS_ICON 100

#endif

