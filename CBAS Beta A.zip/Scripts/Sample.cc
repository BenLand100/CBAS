int scriptmain() {
    return 0;
}